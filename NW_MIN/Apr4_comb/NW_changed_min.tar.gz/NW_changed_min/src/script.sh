#!/bin/sh
time ./nw_match 6_3_70 big.txt 70
